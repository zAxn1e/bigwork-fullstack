import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'https://api.noctradev.com';
const API_KEY  = import.meta.env.VITE_API_KEY || '';

const api = axios.create({
  baseURL: API_BASE,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
});

// ── Request interceptor ──────────────────────────────
api.interceptors.request.use((config) => {
  // Always attach API key
  if (API_KEY) config.headers['x-api-key'] = API_KEY;

  // Attach JWT if available
  const token = localStorage.getItem('bigwork_token');
  if (token) config.headers['Authorization'] = `Bearer ${token}`;

  return config;
});

// ── Response interceptor ─────────────────────────────
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      const isAuthRoute = err.config?.url?.startsWith('/auth');
      if (!isAuthRoute) {
        localStorage.removeItem('bigwork_token');
        localStorage.removeItem('bigwork_user');
        window.location.href = '/login';
      }
    }
    return Promise.reject(err);
  },
);

export default api;
