import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../api/client';
import GigCard from '../components/gig/GigCard';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';
import { PageSpinner } from '../components/ui/Spinner';
import {
  Search, ArrowRight, Sparkles, Shield, Zap,
  Users, Star, TrendingUp
} from 'lucide-react';

export default function Home() {
  const [gigs, setGigs] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([
      api.get('/gigs', { params: { isActive: true } }),
      api.get('/categories'),
    ])
      .then(([gigsRes, catRes]) => {
        setGigs(gigsRes.data.data?.slice(0, 8) || []);
        setCategories(catRes.data.data || []);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    navigate(`/gigs?q=${encodeURIComponent(search)}`);
  };

  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="relative overflow-hidden">
        {/* BG effects */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-primary-600/20 rounded-full blur-[120px]" />
          <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-accent-500/15 rounded-full blur-[100px]" />
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20 sm:py-28 lg:py-36">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 rounded-full bg-primary-500/10 border border-primary-500/20 px-4 py-1.5 text-xs font-semibold text-primary-300 mb-6 animate-fade-in">
              <Sparkles className="w-3.5 h-3.5" />
              แพลตฟอร์มฟรีแลนซ์ชั้นนำ
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black leading-tight animate-fade-in" style={{ animationDelay: '0.1s' }}>
              ค้นหาฟรีแลนซ์
              <span className="gradient-text block">คุณภาพระดับมืออาชีพ</span>
            </h1>

            <p className="mt-6 text-lg text-surface-400 max-w-xl mx-auto leading-relaxed animate-fade-in" style={{ animationDelay: '0.2s' }}>
              เชื่อมต่อกับฟรีแลนซ์ผู้เชี่ยวชาญ พร้อมส่งมอบงานคุณภาพตรงเวลา
            </p>

            {/* Search bar */}
            <form onSubmit={handleSearch} className="mt-10 animate-fade-in" style={{ animationDelay: '0.3s' }}>
              <div className="relative max-w-xl mx-auto">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-surface-500" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="ค้นหาบริการที่คุณต้องการ..."
                  className="w-full rounded-2xl border border-surface-600/50 bg-surface-800/60 backdrop-blur-xl pl-12 pr-36 py-4 text-sm text-surface-100
                    placeholder:text-surface-500 focus:outline-none focus:ring-2 focus:ring-primary-500/50 focus:border-primary-500 transition-all"
                />
                <Button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2">
                  ค้นหา <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
            </form>

            {/* Stats */}
            <div className="mt-14 grid grid-cols-3 gap-6 max-w-md mx-auto animate-fade-in" style={{ animationDelay: '0.4s' }}>
              {[
                { icon: Users, value: '500+', label: 'ฟรีแลนซ์' },
                { icon: Star, value: '4.9', label: 'คะแนนเฉลี่ย' },
                { icon: TrendingUp, value: '1K+', label: 'งานสำเร็จ' },
              ].map((s) => (
                <div key={s.label} className="text-center">
                  <div className="inline-flex items-center justify-center w-10 h-10 rounded-xl bg-surface-800/60 mb-2">
                    <s.icon className="w-5 h-5 text-primary-400" />
                  </div>
                  <p className="text-2xl font-bold text-surface-100">{s.value}</p>
                  <p className="text-xs text-surface-500">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      {categories.length > 0 && (
        <section className="py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl font-bold text-surface-100 mb-8">หมวดหมู่ยอดนิยม</h2>
            <div className="flex flex-wrap gap-3">
              {categories.map((c) => (
                <Link
                  key={c.id}
                  to={`/gigs?categoryId=${c.id}`}
                  className="group glass rounded-xl px-5 py-3 text-sm font-medium text-surface-300 hover:text-primary-300 hover:border-primary-500/30 transition-all duration-200 hover:-translate-y-0.5"
                >
                  {c.name}
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Featured gigs */}
      <section className="py-16 bg-surface-900/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-surface-100">งานแนะนำ</h2>
            <Link to="/gigs" className="text-sm font-medium text-primary-400 hover:text-primary-300 flex items-center gap-1 transition-colors">
              ดูทั้งหมด <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {loading ? (
            <PageSpinner />
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {gigs.map((g) => (
                <GigCard key={g.id} gig={g} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Features */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-bold text-surface-100">ทำไมต้อง BigWork?</h2>
            <p className="mt-3 text-surface-400 max-w-lg mx-auto">บริการที่ออกแบบมาเพื่อความสะดวกและคุณภาพสูงสุด</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: Sparkles, title: 'ฟรีแลนซ์คุณภาพ', desc: 'คัดสรรฟรีแลนซ์ผู้เชี่ยวชาญพร้อมส่งมอบผลงานระดับมืออาชีพ', color: 'from-primary-500 to-primary-600' },
              { icon: Shield, title: 'ปลอดภัย 100%', desc: 'ระบบการชำระเงินที่ปลอดภัยพร้อมการรับประกันคุณภาพงาน', color: 'from-emerald-500 to-emerald-600' },
              { icon: Zap, title: 'รวดเร็วทันใจ', desc: 'เชื่อมต่อกับฟรีแลนซ์ได้ทันทีและเริ่มงานได้อย่างรวดเร็ว', color: 'from-amber-500 to-amber-600' },
            ].map((f) => (
              <div key={f.title} className="glass rounded-2xl p-7 group hover:-translate-y-1 transition-all duration-300">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${f.color} flex items-center justify-center mb-5 shadow-lg group-hover:scale-105 transition-transform`}>
                  <f.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-bold text-surface-100 mb-2">{f.title}</h3>
                <p className="text-sm text-surface-400 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="relative rounded-3xl overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-primary-600 to-accent-600 opacity-90" />
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')] opacity-50" />
            <div className="relative px-8 py-16 sm:px-16 sm:py-20 text-center">
              <h2 className="text-3xl sm:text-4xl font-black text-white mb-4">พร้อมเริ่มต้นหรือยัง?</h2>
              <p className="text-white/80 text-lg mb-8 max-w-lg mx-auto">สมัครสมาชิกวันนี้แล้วเริ่มค้นหาฟรีแลนซ์คุณภาพ</p>
              <div className="flex items-center justify-center gap-3 flex-wrap">
                <Button size="lg" variant="secondary" onClick={() => navigate('/register')}>
                  สมัครสมาชิกฟรี <ArrowRight className="w-4 h-4" />
                </Button>
                <Button size="lg" variant="ghost" className="text-white hover:bg-white/10" onClick={() => navigate('/gigs')}>
                  ดูงานทั้งหมด
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
