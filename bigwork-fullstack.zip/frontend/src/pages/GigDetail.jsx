import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api/client';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { formatPrice } from '../utils/formatPrice';
import { formatDate } from '../utils/formatDate';
import { mediaUrl } from '../utils/media';
import { getUserProfileImage } from '../utils/userProfileImage';
import Badge from '../components/ui/Badge';
import Button from '../components/ui/Button';
import Modal from '../components/ui/Modal';
import Input from '../components/ui/Input';
import Textarea from '../components/ui/Textarea';
import StarRating from '../components/ui/StarRating';
import ReviewCard from '../components/review/ReviewCard';
import { PageSpinner } from '../components/ui/Spinner';
import { User, ShoppingCart, ImageOff, ChevronLeft, ChevronRight } from 'lucide-react';

export default function GigDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [gig, setGig] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [imgIdx, setImgIdx] = useState(0);
  const [orderModal, setOrderModal] = useState(false);
  const [orderForm, setOrderForm] = useState({ message: '', agreedPrice: '' });
  const [ordering, setOrdering] = useState(false);

  useEffect(() => {
    setLoading(true);
    Promise.all([
      api.get(`/gigs/${id}`),
      api.get('/reviews'),
    ]).then(([gigRes, revRes]) => {
      setGig(gigRes.data.data);
      const gigReviews = (revRes.data.data || []).filter((r) => r.gigId === Number(id));
      setReviews(gigReviews);
    }).catch(() => navigate('/gigs'))
      .finally(() => setLoading(false));
  }, [id]);

  const handleOrder = async (e) => {
    e.preventDefault();
    if (!user) { navigate('/login'); return; }
    setOrdering(true);
    try {
      await api.post('/orders', {
        gigId: Number(id),
        clientId: user.id,
        message: orderForm.message || undefined,
        agreedPrice: Number(orderForm.agreedPrice) || gig.price,
      });
      toast.success('สั่งซื้อสำเร็จ!');
      setOrderModal(false);
      navigate('/profile/orders');
    } catch (err) {
      toast.error(err.response?.data?.message || 'ไม่สามารถสั่งซื้อได้');
    } finally { setOrdering(false); }
  };

  if (loading) return <PageSpinner />;
  if (!gig) return null;

  const images = (gig.mediaLinks || [])
    .sort((a, b) => a.sortOrder - b.sortOrder)
    .map((m) => m.mediaAsset);

  const avgRating = reviews.length > 0
    ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1)
    : null;
  const ownerProfileImage = getUserProfileImage(gig.owner);

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left: images + description */}
        <div className="lg:col-span-2 space-y-6">
          {/* Image gallery */}
          <div className="glass rounded-2xl overflow-hidden">
            <div className="relative aspect-video bg-surface-800">
              {images.length > 0 ? (
                <img src={mediaUrl(images[imgIdx]?.webpUrl)} alt={gig.title}
                  className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <ImageOff className="w-16 h-16 text-surface-700" />
                </div>
              )}
              {images.length > 1 && (
                <>
                  <button onClick={() => setImgIdx((p) => (p - 1 + images.length) % images.length)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-surface-700/80 transition-colors cursor-pointer">
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button onClick={() => setImgIdx((p) => (p + 1) % images.length)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-surface-700/80 transition-colors cursor-pointer">
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </>
              )}
            </div>
            {images.length > 1 && (
              <div className="flex gap-2 p-3 overflow-x-auto">
                {images.map((img, i) => (
                  <button key={img.id} onClick={() => setImgIdx(i)}
                    className={`shrink-0 w-20 h-14 rounded-lg overflow-hidden border-2 transition-all cursor-pointer ${i === imgIdx ? 'border-primary-500' : 'border-transparent opacity-60 hover:opacity-100'}`}>
                    <img src={mediaUrl(img.thumbnailUrl || img.webpUrl)} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Description */}
          <div className="glass rounded-2xl p-6">
            <h2 className="text-lg font-bold text-surface-100 mb-4">รายละเอียดงาน</h2>
            <p className="text-surface-300 leading-relaxed whitespace-pre-wrap">{gig.description}</p>
          </div>

          {/* Reviews */}
          <div className="glass rounded-2xl p-6">
            <h2 className="text-lg font-bold text-surface-100 mb-4">
              รีวิว {avgRating && <span className="text-sm font-normal text-surface-400">({avgRating} ★ · {reviews.length} รีวิว)</span>}
            </h2>
            {reviews.length === 0 ? (
              <p className="text-sm text-surface-500">ยังไม่มีรีวิว</p>
            ) : (
              <div className="space-y-4">{reviews.map((r) => <ReviewCard key={r.id} review={r} />)}</div>
            )}
          </div>
        </div>

        {/* Right: sidebar */}
        <div className="space-y-5">
          <div className="glass rounded-2xl p-6 sticky top-24">
            {gig.category && <Badge color="purple" className="mb-3">{gig.category.name}</Badge>}
            <h1 className="text-xl font-bold text-surface-100 mb-3">{gig.title}</h1>

            {/* Owner */}
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-full overflow-hidden bg-gradient-to-br from-primary-500 to-accent-500 flex items-center justify-center text-sm font-bold text-white">
                {ownerProfileImage ? (
                  <img src={mediaUrl(ownerProfileImage)} alt="" className="w-full h-full object-cover" />
                ) : (
                  gig.owner?.firstname?.[0] || <User className="w-4 h-4" />
                )}
              </div>
              <div>
                <p className="text-sm font-semibold text-surface-200">{gig.owner?.displayName || `${gig.owner?.firstname} ${gig.owner?.lastname}`}</p>
                <p className="text-xs text-surface-500">{gig.owner?.role === 'FREELANCER' ? 'ฟรีแลนซ์' : 'ผู้ใช้งาน'}</p>
              </div>
            </div>

            <div className="border-t border-surface-700/50 pt-5 mb-5">
              <div className="flex items-baseline justify-between">
                <span className="text-sm text-surface-400">ราคา</span>
                <span className="text-2xl font-bold gradient-text">{formatPrice(gig.price)}</span>
              </div>
            </div>

            <Button className="w-full" size="lg" onClick={() => { if (!user) navigate('/login'); else { setOrderForm({ message: '', agreedPrice: gig.price }); setOrderModal(true); } }}>
              <ShoppingCart className="w-5 h-5" /> สั่งซื้อเลย
            </Button>

            <p className="text-xs text-surface-500 text-center mt-3">สร้างเมื่อ {formatDate(gig.createdAt)}</p>
          </div>
        </div>
      </div>

      {/* Order Modal */}
      <Modal isOpen={orderModal} onClose={() => setOrderModal(false)} title="สั่งซื้อบริการ">
        <form onSubmit={handleOrder} className="space-y-5">
          <div className="glass-light rounded-xl p-4">
            <p className="text-sm font-semibold text-surface-200">{gig.title}</p>
            <p className="text-xs text-surface-400 mt-1">โดย {gig.owner?.displayName}</p>
          </div>
          <Input label="ราคาที่ตกลง (บาท)" type="number" min="1" value={orderForm.agreedPrice}
            onChange={(e) => setOrderForm({ ...orderForm, agreedPrice: e.target.value })} required />
          <Textarea label="ข้อความถึงฟรีแลนซ์ (ไม่บังคับ)" value={orderForm.message}
            onChange={(e) => setOrderForm({ ...orderForm, message: e.target.value })} placeholder="อธิบายรายละเอียดงานที่ต้องการ..." />
          <Button type="submit" loading={ordering} className="w-full"><ShoppingCart className="w-4 h-4" /> ยืนยันสั่งซื้อ</Button>
        </form>
      </Modal>
    </div>
  );
}
