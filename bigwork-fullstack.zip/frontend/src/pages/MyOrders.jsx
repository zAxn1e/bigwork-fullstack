import { useState, useEffect } from 'react';
import { Navigate, Link } from 'react-router-dom';
import api from '../api/client';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { formatPrice } from '../utils/formatPrice';
import { formatDateTime } from '../utils/formatDate';
import OrderStatusBadge from '../components/order/OrderStatusBadge';
import Button from '../components/ui/Button';
import Modal from '../components/ui/Modal';
import StarRating from '../components/ui/StarRating';
import Textarea from '../components/ui/Textarea';
import Select from '../components/ui/Select';
import { PageSpinner } from '../components/ui/Spinner';
import EmptyState from '../components/ui/EmptyState';
import { ShoppingCart, MessageSquare } from 'lucide-react';

export default function MyOrders() {
  const { user, loading: authLoading } = useAuth();
  const toast = useToast();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [reviewModal, setReviewModal] = useState(null);
  const [reviewForm, setReviewForm] = useState({ rating: 5, comment: '' });
  const [submittingReview, setSubmittingReview] = useState(false);

  if (!authLoading && !user) return <Navigate to="/login" replace />;

  const fetchOrders = async () => {
    try {
      const params = {};
      // Fetch orders where user is client or seller
      const [c, s] = await Promise.all([
        api.get('/orders', { params: { clientId: user?.id, ...( filter ? { status: filter } : {}) } }),
        api.get('/orders', { params: { sellerId: user?.id, ...( filter ? { status: filter } : {}) } }),
      ]);
      const all = [...(c.data.data || []), ...(s.data.data || [])];
      const unique = Array.from(new Map(all.map((o) => [o.id, o])).values());
      unique.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      setOrders(unique);
    } catch { setOrders([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { if (user) fetchOrders(); }, [user, filter]);

  const updateStatus = async (orderId, status) => {
    try {
      await api.patch(`/orders/${orderId}/status`, { status });
      toast.success('อัปเดตสถานะสำเร็จ');
      fetchOrders();
    } catch (err) { toast.error(err.response?.data?.message || 'อัปเดตไม่สำเร็จ'); }
  };

  const handleReview = async (e) => {
    e.preventDefault();
    setSubmittingReview(true);
    try {
      await api.post('/reviews', {
        orderId: reviewModal.id,
        authorId: user.id,
        targetUserId: reviewModal.clientId === user.id ? reviewModal.sellerId : reviewModal.clientId,
        rating: reviewForm.rating,
        comment: reviewForm.comment || undefined,
      });
      toast.success('ส่งรีวิวสำเร็จ!');
      setReviewModal(null);
      setReviewForm({ rating: 5, comment: '' });
    } catch (err) { toast.error(err.response?.data?.message || 'ส่งรีวิวไม่สำเร็จ'); }
    finally { setSubmittingReview(false); }
  };

  if (loading) return <PageSpinner />;

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8 flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold text-surface-100">คำสั่งซื้อ</h1>
          <p className="text-surface-400 text-sm mt-1">ดูและจัดการคำสั่งซื้อทั้งหมด</p>
        </div>
        <Select value={filter} onChange={(e) => setFilter(e.target.value)} className="w-48">
          <option value="">ทุกสถานะ</option>
          <option value="PENDING">รอดำเนินการ</option>
          <option value="IN_PROGRESS">กำลังดำเนินการ</option>
          <option value="COMPLETED">เสร็จสิ้น</option>
          <option value="CANCELLED">ยกเลิก</option>
        </Select>
      </div>

      {orders.length === 0 ? (
        <EmptyState icon={ShoppingCart} title="ไม่มีคำสั่งซื้อ" description="ยังไม่มีคำสั่งซื้อที่ตรงกับเงื่อนไข" />
      ) : (
        <div className="space-y-4">
          {orders.map((o) => {
            const isSeller = o.sellerId === user?.id;
            return (
              <div key={o.id} className="glass rounded-2xl p-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <Link to={`/gigs/${o.gigId}`} className="text-base font-semibold text-surface-100 hover:text-primary-300 transition-colors truncate">
                        {o.gig?.title || `งาน #${o.gigId}`}
                      </Link>
                      <OrderStatusBadge status={o.status} />
                    </div>
                    <div className="text-sm text-surface-400 space-y-0.5">
                      <p>{isSeller ? 'ลูกค้า' : 'ผู้ขาย'}: {isSeller ? (o.client?.displayName || o.client?.email) : (o.seller?.displayName || o.seller?.email)}</p>
                      <p>ราคา: {formatPrice(o.agreedPrice)} · {formatDateTime(o.createdAt)}</p>
                      {o.message && <p className="text-surface-500 italic">"{o.message}"</p>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0 flex-wrap">
                    {isSeller && o.status === 'PENDING' && (
                      <>
                        <Button size="sm" variant="accent" onClick={() => updateStatus(o.id, 'IN_PROGRESS')}>รับงาน</Button>
                        <Button size="sm" variant="danger" onClick={() => updateStatus(o.id, 'CANCELLED')}>ปฏิเสธ</Button>
                      </>
                    )}
                    {isSeller && o.status === 'IN_PROGRESS' && (
                      <Button size="sm" onClick={() => updateStatus(o.id, 'COMPLETED')}>ส่งมอบงาน</Button>
                    )}
                    {!isSeller && o.status === 'PENDING' && (
                      <Button size="sm" variant="danger" onClick={() => updateStatus(o.id, 'CANCELLED')}>ยกเลิก</Button>
                    )}
                    {o.status === 'COMPLETED' && (
                      <Button size="sm" variant="secondary" onClick={() => { setReviewModal(o); setReviewForm({ rating: 5, comment: '' }); }}>
                        <MessageSquare className="w-4 h-4" /> รีวิว
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Review Modal */}
      <Modal isOpen={!!reviewModal} onClose={() => setReviewModal(null)} title="เขียนรีวิว">
        <form onSubmit={handleReview} className="space-y-5">
          <div>
            <label className="text-sm font-medium text-surface-300 mb-2 block">คะแนน</label>
            <StarRating rating={reviewForm.rating} interactive onChange={(r) => setReviewForm({ ...reviewForm, rating: r })} size={28} />
          </div>
          <Textarea label="ความคิดเห็น (ไม่บังคับ)" value={reviewForm.comment}
            onChange={(e) => setReviewForm({ ...reviewForm, comment: e.target.value })} placeholder="เขียนความคิดเห็น..." />
          <Button type="submit" loading={submittingReview} className="w-full">ส่งรีวิว</Button>
        </form>
      </Modal>
    </div>
  );
}
