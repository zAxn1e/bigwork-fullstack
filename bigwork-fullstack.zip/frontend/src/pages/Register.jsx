import { useState } from 'react';
import { Link, useNavigate, Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import Input from '../components/ui/Input';
import Textarea from '../components/ui/Textarea';
import Button from '../components/ui/Button';
import { UserPlus, Briefcase, X } from 'lucide-react';

export default function Register() {
  const { user, register } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    firstname: '', lastname: '', email: '', password: '',
    birthday: '', telephoneNumber: '', role: 'CLIENT', bio: '',
  });
  const [skills, setSkills] = useState([]);
  const [skillInput, setSkillInput] = useState('');

  if (user) return <Navigate to="/" replace />;

  const addSkill = () => {
    const s = skillInput.trim();
    if (s && !skills.includes(s)) setSkills([...skills, s]);
    setSkillInput('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await register({
        ...form,
        birthday: new Date(form.birthday).toISOString(),
        skills,
      });
      toast.success('สมัครสมาชิกสำเร็จ!');
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.message || 'เกิดข้อผิดพลาด');
    } finally {
      setLoading(false);
    }
  };

  const set = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  return (
    <div className="min-h-[calc(100dvh-64px)] flex items-center justify-center px-4 py-12">
      <div className="fixed inset-0 -z-10">
        <div className="absolute top-1/3 right-1/3 w-[400px] h-[400px] bg-primary-600/15 rounded-full blur-[100px]" />
      </div>

      <div className="w-full max-w-lg animate-slide-up">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2.5 mb-6">
            <div className="flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-br from-primary-500 to-accent-500 shadow-lg shadow-primary-500/25">
              <Briefcase className="w-6 h-6 text-white" />
            </div>
          </Link>
          <h1 className="text-2xl font-bold text-surface-100">สร้างบัญชีใหม่</h1>
          <p className="text-sm text-surface-400 mt-1">เริ่มต้นใช้งาน BigWork วันนี้</p>
        </div>

        <form onSubmit={handleSubmit} className="glass rounded-2xl p-8 space-y-5">
          <div className="flex gap-3">
            {[{ value: 'CLIENT', label: 'ผู้ว่าจ้าง' }, { value: 'FREELANCER', label: 'ฟรีแลนซ์' }].map((r) => (
              <button key={r.value} type="button" onClick={() => setForm({ ...form, role: r.value })}
                className={`flex-1 py-3 rounded-xl text-sm font-semibold transition-all cursor-pointer border
                  ${form.role === r.value ? 'bg-primary-500/15 border-primary-500/40 text-primary-300' : 'bg-surface-800/40 border-surface-600 text-surface-400 hover:border-surface-500'}`}>
                {r.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Input label="ชื่อ" value={form.firstname} onChange={set('firstname')} required placeholder="ชื่อ" />
            <Input label="นามสกุล" value={form.lastname} onChange={set('lastname')} required placeholder="นามสกุล" />
          </div>
          <Input label="อีเมล" type="email" value={form.email} onChange={set('email')} required placeholder="you@example.com" />
          <Input label="รหัสผ่าน" type="password" value={form.password} onChange={set('password')} required placeholder="อย่างน้อย 6 ตัวอักษร" />
          <div className="grid grid-cols-2 gap-4">
            <Input label="วันเกิด" type="date" value={form.birthday} onChange={set('birthday')} required />
            <Input label="เบอร์โทร" value={form.telephoneNumber} onChange={set('telephoneNumber')} required placeholder="0812345678" />
          </div>

          {/* Skills */}
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-surface-300">ทักษะ</label>
            <div className="flex gap-2">
              <input type="text" value={skillInput} onChange={(e) => setSkillInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addSkill(); } }}
                placeholder="พิมพ์แล้วกด Enter"
                className="flex-1 rounded-xl border border-surface-600 bg-surface-800/60 px-4 py-2.5 text-sm text-surface-100 placeholder:text-surface-500 focus:outline-none focus:ring-2 focus:ring-primary-500/50 focus:border-primary-500 transition-all" />
              <Button type="button" variant="secondary" onClick={addSkill}>เพิ่ม</Button>
            </div>
            {skills.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {skills.map((s) => (
                  <span key={s} className="inline-flex items-center gap-1 rounded-full bg-primary-500/15 border border-primary-500/30 px-3 py-1 text-xs font-medium text-primary-300">
                    {s}
                    <button type="button" onClick={() => setSkills(skills.filter((x) => x !== s))} className="hover:text-red-400 cursor-pointer"><X className="w-3 h-3" /></button>
                  </span>
                ))}
              </div>
            )}
          </div>

          <Textarea label="แนะนำตัว (ไม่บังคับ)" value={form.bio} onChange={set('bio')} placeholder="เล่าเกี่ยวกับตัวคุณ..." />
          <Button type="submit" loading={loading} className="w-full"><UserPlus className="w-4 h-4" /> สมัครสมาชิก</Button>
        </form>

        <p className="text-center text-sm text-surface-400 mt-6">
          มีบัญชีอยู่แล้ว? <Link to="/login" className="text-primary-400 hover:text-primary-300 font-medium">เข้าสู่ระบบ</Link>
        </p>
      </div>
    </div>
  );
}
