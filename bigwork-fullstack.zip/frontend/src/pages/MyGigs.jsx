import { useState, useEffect } from 'react';
import { Link, Navigate } from 'react-router-dom';
import api from '../api/client';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { formatPrice } from '../utils/formatPrice';
import { formatDate } from '../utils/formatDate';
import Badge from '../components/ui/Badge';
import Button from '../components/ui/Button';
import { PageSpinner } from '../components/ui/Spinner';
import EmptyState from '../components/ui/EmptyState';
import { Plus, Edit, Trash2, Eye, EyeOff, Briefcase } from 'lucide-react';

export default function MyGigs() {
  const { user, loading: authLoading } = useAuth();
  const toast = useToast();
  const [gigs, setGigs] = useState([]);
  const [loading, setLoading] = useState(true);

  if (!authLoading && !user) return <Navigate to="/login" replace />;

  useEffect(() => {
    api.get('/gigs').then((r) => {
      const myGigs = (r.data.data || []).filter((g) => g.ownerId === user?.id);
      setGigs(myGigs);
    }).catch(() => {}).finally(() => setLoading(false));
  }, [user]);

  const handleDelete = async (id) => {
    if (!confirm('ต้องการลบงานนี้ใช่ไหม?')) return;
    try {
      await api.delete(`/gigs/${id}`);
      setGigs(gigs.filter((g) => g.id !== id));
      toast.success('ลบงานสำเร็จ');
    } catch { toast.error('ลบไม่สำเร็จ'); }
  };

  const handleToggle = async (gig) => {
    try {
      const { data } = await api.put(`/gigs/${gig.id}`, { isActive: !gig.isActive });
      setGigs(gigs.map((g) => g.id === gig.id ? { ...g, isActive: !g.isActive } : g));
      toast.success(gig.isActive ? 'ปิดการมองเห็นแล้ว' : 'เปิดการมองเห็นแล้ว');
    } catch { toast.error('อัปเดตไม่สำเร็จ'); }
  };

  if (loading) return <PageSpinner />;

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-surface-100">งานของฉัน</h1>
          <p className="text-surface-400 text-sm mt-1">จัดการงานบริการของคุณ</p>
        </div>
        <Link to="/profile/gigs/new">
          <Button><Plus className="w-4 h-4" /> สร้างงานใหม่</Button>
        </Link>
      </div>

      {gigs.length === 0 ? (
        <EmptyState icon={Briefcase} title="ยังไม่มีงาน" description="สร้างงานบริการแรกของคุณ">
          <Link to="/profile/gigs/new"><Button><Plus className="w-4 h-4" /> สร้างงานใหม่</Button></Link>
        </EmptyState>
      ) : (
        <div className="space-y-4">
          {gigs.map((g) => (
            <div key={g.id} className="glass rounded-2xl p-5 flex flex-col sm:flex-row items-start sm:items-center gap-4 hover:shadow-lg transition-shadow">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-base font-semibold text-surface-100 truncate">{g.title}</h3>
                  <Badge color={g.isActive ? 'green' : 'gray'}>{g.isActive ? 'เปิด' : 'ปิด'}</Badge>
                </div>
                <p className="text-sm text-surface-400 line-clamp-1">{g.description}</p>
                <div className="flex items-center gap-4 mt-2 text-xs text-surface-500">
                  <span>{formatPrice(g.price)}</span>
                  <span>{g.category?.name || '-'}</span>
                  <span>{formatDate(g.createdAt)}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Button variant="ghost" size="sm" onClick={() => handleToggle(g)}>
                  {g.isActive ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
                <Link to={`/profile/gigs/${g.id}/edit`}>
                  <Button variant="secondary" size="sm"><Edit className="w-4 h-4" /></Button>
                </Link>
                <Button variant="danger" size="sm" onClick={() => handleDelete(g.id)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
