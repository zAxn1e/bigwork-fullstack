import { useState, useEffect } from 'react';
import { useNavigate, Navigate } from 'react-router-dom';
import api from '../api/client';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { formatDate } from '../utils/formatDate';
import { toInputDate } from '../utils/formatDate';
import { mediaUrl } from '../utils/media';
import { getUserProfileImage } from '../utils/userProfileImage';
import Input from '../components/ui/Input';
import Textarea from '../components/ui/Textarea';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';
import { PageSpinner } from '../components/ui/Spinner';
import { Save, Camera, Trash2, X, User as UserIcon } from 'lucide-react';

export default function Profile() {
  const { user, loading: authLoading, updateUser } = useAuth();
  const toast = useToast();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({});
  const [skills, setSkills] = useState([]);
  const [skillInput, setSkillInput] = useState('');

  if (!authLoading && !user) return <Navigate to="/login" replace />;

  useEffect(() => {
    api.get('/profile').then((r) => {
      const p = r.data.data.user;
      setProfile(p);
      setForm({
        firstname: p.firstname || '', lastname: p.lastname || '',
        birthday: toInputDate(p.birthday), telephoneNumber: p.telephoneNumber || '',
        bio: p.bio || '',
      });
      setSkills(p.skills || []);
    }).catch(() => toast.error('ไม่สามารถโหลดโปรไฟล์ได้'))
      .finally(() => setLoading(false));
  }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = { ...form, skills, birthday: new Date(form.birthday).toISOString() };
      const { data } = await api.patch('/profile', payload);
      if (data.data.user) { setProfile(data.data.user); updateUser(data.data.user); }
      toast.success('บันทึกโปรไฟล์สำเร็จ!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'บันทึกไม่สำเร็จ');
    } finally { setSaving(false); }
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fd = new FormData();
    fd.append('image', file);
    try {
      const { data } = await api.post('/profile/image', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast.success('อัปโหลดรูปโปรไฟล์สำเร็จ!');
      if (data.data.user) { setProfile(data.data.user); updateUser(data.data.user); }
      else { const r = await api.get('/profile'); setProfile(r.data.data.user); updateUser(r.data.data.user); }
    } catch { toast.error('อัปโหลดไม่สำเร็จ'); }
  };

  const handleImageDelete = async () => {
    try {
      await api.delete('/profile/image');
      toast.success('ลบรูปโปรไฟล์แล้ว');
      const r = await api.get('/profile');
      setProfile(r.data.data.user); updateUser(r.data.data.user);
    } catch { toast.error('ลบไม่สำเร็จ'); }
  };

  const addSkill = () => { const s = skillInput.trim(); if (s && !skills.includes(s)) setSkills([...skills, s]); setSkillInput(''); };
  const set = (f) => (e) => setForm({ ...form, [f]: e.target.value });

  if (loading) return <PageSpinner />;

  const roleLabel = { CLIENT: 'ผู้ว่าจ้าง', FREELANCER: 'ฟรีแลนซ์', ADMIN: 'แอดมิน' };
  const profileImage = getUserProfileImage(profile);

  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-surface-100 mb-8">โปรไฟล์</h1>

      {/* Avatar */}
      <div className="glass rounded-2xl p-6 mb-6 flex flex-col sm:flex-row items-center gap-6">
        <div className="relative group">
          <div className="w-24 h-24 rounded-full overflow-hidden bg-gradient-to-br from-primary-500 to-accent-500 flex items-center justify-center text-3xl font-bold text-white">
            {profileImage
              ? <img src={mediaUrl(profileImage)} alt="" className="w-full h-full object-cover" />
              : (profile?.firstname?.[0] || <UserIcon className="w-10 h-10" />)}
          </div>
          <label className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
            <Camera className="w-6 h-6 text-white" />
            <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
          </label>
        </div>
        <div className="text-center sm:text-left">
          <h2 className="text-xl font-bold text-surface-100">{profile?.displayName || `${profile?.firstname} ${profile?.lastname}`}</h2>
          <p className="text-sm text-surface-400">{profile?.email}</p>
          <div className="flex items-center gap-2 mt-2 justify-center sm:justify-start">
            <Badge color={profile?.role === 'ADMIN' ? 'yellow' : profile?.role === 'FREELANCER' ? 'cyan' : 'purple'}>
              {roleLabel[profile?.role] || profile?.role}
            </Badge>
            <span className="text-xs text-surface-500">สมาชิกตั้งแต่ {formatDate(profile?.createdAt)}</span>
          </div>
          {profileImage && (
            <button onClick={handleImageDelete} className="mt-2 text-xs text-red-400 hover:text-red-300 flex items-center gap-1 cursor-pointer">
              <Trash2 className="w-3 h-3" /> ลบรูปโปรไฟล์
            </button>
          )}
        </div>
      </div>

      {/* Edit form */}
      <form onSubmit={handleSave} className="glass rounded-2xl p-6 space-y-5">
        <div className="grid grid-cols-2 gap-4">
          <Input label="ชื่อ" value={form.firstname} onChange={set('firstname')} required />
          <Input label="นามสกุล" value={form.lastname} onChange={set('lastname')} required />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <Input label="วันเกิด" type="date" value={form.birthday} onChange={set('birthday')} required />
          <Input label="เบอร์โทร" value={form.telephoneNumber} onChange={set('telephoneNumber')} required />
        </div>
        <Textarea label="แนะนำตัว" value={form.bio} onChange={set('bio')} placeholder="เล่าเกี่ยวกับตัวคุณ..." />

        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-surface-300">ทักษะ</label>
          <div className="flex gap-2">
            <input type="text" value={skillInput} onChange={(e) => setSkillInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addSkill(); } }}
              placeholder="พิมพ์แล้วกด Enter"
              className="flex-1 rounded-xl border border-surface-600 bg-surface-800/60 px-4 py-2.5 text-sm text-surface-100 placeholder:text-surface-500 focus:outline-none focus:ring-2 focus:ring-primary-500/50 transition-all" />
            <Button type="button" variant="secondary" onClick={addSkill}>เพิ่ม</Button>
          </div>
          {skills.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
              {skills.map((s) => (
                <span key={s} className="inline-flex items-center gap-1 rounded-full bg-primary-500/15 border border-primary-500/30 px-3 py-1 text-xs font-medium text-primary-300">
                  {s} <button type="button" onClick={() => setSkills(skills.filter((x) => x !== s))} className="hover:text-red-400 cursor-pointer"><X className="w-3 h-3" /></button>
                </span>
              ))}
            </div>
          )}
        </div>

        <Button type="submit" loading={saving}><Save className="w-4 h-4" /> บันทึก</Button>
      </form>
    </div>
  );
}
