import { useState, useEffect } from 'react';
import { useParams, useNavigate, Navigate } from 'react-router-dom';
import api from '../api/client';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { mediaUrl } from '../utils/media';
import Input from '../components/ui/Input';
import Textarea from '../components/ui/Textarea';
import Select from '../components/ui/Select';
import Button from '../components/ui/Button';
import { PageSpinner } from '../components/ui/Spinner';
import { Save, Upload, X, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function GigForm() {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const { user, loading: authLoading } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(isEdit);
  const [saving, setSaving] = useState(false);
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState({ title: '', description: '', price: '', categoryId: '', isActive: true });
  const [mediaFiles, setMediaFiles] = useState([]);
  const [existingMedia, setExistingMedia] = useState([]);

  if (!authLoading && !user) return <Navigate to="/login" replace />;

  useEffect(() => {
    api.get('/categories').then((r) => setCategories(r.data.data || [])).catch(() => {});
    if (isEdit) {
      api.get(`/gigs/${id}`).then((r) => {
        const g = r.data.data;
        setForm({ title: g.title, description: g.description, price: g.price, categoryId: g.categoryId, isActive: g.isActive });
        const media = (g.mediaLinks || []).sort((a, b) => a.sortOrder - b.sortOrder).map((m) => ({ ...m.mediaAsset, linkId: m.id }));
        setExistingMedia(media);
      }).catch(() => navigate('/profile/gigs')).finally(() => setLoading(false));
    }
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = { ...form, price: Number(form.price), categoryId: Number(form.categoryId) };
      let gigId = id;
      if (isEdit) {
        await api.put(`/gigs/${id}`, payload);
      } else {
        const { data } = await api.post('/gigs', payload);
        gigId = data.data.id;
      }
      // Upload new media
      for (const file of mediaFiles) {
        const fd = new FormData();
        fd.append('file', file);
        await api.post(`/gigs/${gigId}/media/upload`, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      }
      toast.success(isEdit ? 'อัปเดตงานสำเร็จ!' : 'สร้างงานสำเร็จ!');
      navigate('/profile/gigs');
    } catch (err) {
      toast.error(err.response?.data?.message || 'บันทึกไม่สำเร็จ');
    } finally { setSaving(false); }
  };

  const handleDeleteMedia = async (media) => {
    try {
      await api.delete(`/gigs/${id}/media/${media.id}`);
      setExistingMedia(existingMedia.filter((m) => m.id !== media.id));
      toast.success('ลบรูปสำเร็จ');
    } catch { toast.error('ลบรูปไม่สำเร็จ'); }
  };

  const set = (f) => (e) => setForm({ ...form, [f]: e.target.value });

  if (loading) return <PageSpinner />;

  return (
    <div className="mx-auto max-w-2xl px-4 sm:px-6 lg:px-8 py-8">
      <Link to="/profile/gigs" className="inline-flex items-center gap-1.5 text-sm text-surface-400 hover:text-primary-400 mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4" /> กลับ
      </Link>
      <h1 className="text-3xl font-bold text-surface-100 mb-8">{isEdit ? 'แก้ไขงาน' : 'สร้างงานใหม่'}</h1>

      <form onSubmit={handleSubmit} className="glass rounded-2xl p-6 space-y-5">
        <Input label="ชื่องาน" value={form.title} onChange={set('title')} required placeholder="เช่น ออกแบบเว็บไซต์" />
        <Textarea label="รายละเอียด" value={form.description} onChange={set('description')} required placeholder="อธิบายรายละเอียดงาน..." />
        <div className="grid grid-cols-2 gap-4">
          <Input label="ราคา (บาท)" type="number" min="1" value={form.price} onChange={set('price')} required />
          <Select label="หมวดหมู่" value={form.categoryId} onChange={set('categoryId')} required>
            <option value="">เลือกหมวดหมู่</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
        </div>

        {/* Existing media */}
        {existingMedia.length > 0 && (
          <div>
            <label className="text-sm font-medium text-surface-300 mb-2 block">รูปภาพปัจจุบัน</label>
            <div className="flex flex-wrap gap-3">
              {existingMedia.map((m) => (
                <div key={m.id} className="relative w-24 h-18 rounded-xl overflow-hidden border border-surface-600 group">
                  <img src={mediaUrl(m.thumbnailUrl || m.webpUrl)} alt="" className="w-full h-full object-cover" />
                  <button type="button" onClick={() => handleDeleteMedia(m)}
                    className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                    <X className="w-5 h-5 text-red-400" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Upload new media */}
        <div>
          <label className="text-sm font-medium text-surface-300 mb-2 block">เพิ่มรูปภาพ</label>
          <label className="flex items-center justify-center gap-2 rounded-xl border-2 border-dashed border-surface-600 bg-surface-800/30 p-6 cursor-pointer hover:border-primary-500/50 transition-colors">
            <Upload className="w-5 h-5 text-surface-400" />
            <span className="text-sm text-surface-400">{mediaFiles.length > 0 ? `เลือกแล้ว ${mediaFiles.length} ไฟล์` : 'คลิกเพื่อเลือกรูปภาพ'}</span>
            <input type="file" multiple accept="image/*" onChange={(e) => setMediaFiles([...e.target.files])} className="hidden" />
          </label>
        </div>

        <Button type="submit" loading={saving} className="w-full"><Save className="w-4 h-4" /> {isEdit ? 'บันทึกการเปลี่ยนแปลง' : 'สร้างงาน'}</Button>
      </form>
    </div>
  );
}
