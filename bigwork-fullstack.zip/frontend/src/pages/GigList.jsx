import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../api/client';
import GigCard from '../components/gig/GigCard';
import { PageSpinner } from '../components/ui/Spinner';
import EmptyState from '../components/ui/EmptyState';
import Select from '../components/ui/Select';
import { Search, Briefcase } from 'lucide-react';

export default function GigList() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [gigs, setGigs] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [catId, setCatId] = useState(searchParams.get('categoryId') || '');

  const fetchGigs = async () => {
    setLoading(true);
    try {
      const params = { isActive: true };
      if (query.trim()) params.q = query.trim();
      if (catId) params.categoryId = Number(catId);
      const { data } = await api.get('/gigs', { params });
      setGigs(data.data || []);
    } catch { setGigs([]); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    api.get('/categories').then((r) => setCategories(r.data.data || [])).catch(() => {});
  }, []);

  useEffect(() => { fetchGigs(); }, [query, catId]);

  const handleSearch = (e) => {
    e.preventDefault();
    const p = new URLSearchParams();
    if (query.trim()) p.set('q', query.trim());
    if (catId) p.set('categoryId', catId);
    setSearchParams(p);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-surface-100 mb-2">ค้นหางาน</h1>
        <p className="text-surface-400">ค้นหาบริการฟรีแลนซ์ที่เหมาะกับคุณ</p>
      </div>

      {/* Filters */}
      <form onSubmit={handleSearch} className="glass rounded-2xl p-5 mb-8 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-500" />
          <input type="text" value={query} onChange={(e) => setQuery(e.target.value)}
            placeholder="ค้นหาด้วยชื่องาน..."
            className="w-full rounded-xl border border-surface-600 bg-surface-800/60 pl-10 pr-4 py-2.5 text-sm text-surface-100 placeholder:text-surface-500 focus:outline-none focus:ring-2 focus:ring-primary-500/50 focus:border-primary-500 transition-all" />
        </div>
        <Select value={catId} onChange={(e) => setCatId(e.target.value)} className="sm:w-48">
          <option value="">ทุกหมวดหมู่</option>
          {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </Select>
        <button type="submit" className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-primary-600 to-primary-500 text-white text-sm font-semibold hover:from-primary-500 hover:to-primary-400 transition-all cursor-pointer">
          ค้นหา
        </button>
      </form>

      {/* Results */}
      {loading ? <PageSpinner /> : gigs.length === 0 ? (
        <EmptyState icon={Briefcase} title="ไม่พบงาน" description="ลองค้นหาด้วยคำค้นหาอื่น" />
      ) : (
        <>
          <p className="text-sm text-surface-400 mb-5">พบ {gigs.length} งาน</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {gigs.map((g) => <GigCard key={g.id} gig={g} />)}
          </div>
        </>
      )}
    </div>
  );
}
