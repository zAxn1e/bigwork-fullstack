import { useState, useEffect } from 'react';
import api from '../../api/client';
import { useToast } from '../../contexts/ToastContext';
import { formatPrice } from '../../utils/formatPrice';
import { formatDate } from '../../utils/formatDate';
import Badge from '../../components/ui/Badge';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';
import { PageSpinner } from '../../components/ui/Spinner';
import { Search, Trash2 } from 'lucide-react';

export default function AdminGigs() {
  const toast = useToast();
  const [gigs, setGigs] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState('');

  const fetchGigs = () => {
    setLoading(true);
    const params = {};
    if (search.trim()) params.q = search.trim();
    if (catFilter) params.categoryId = Number(catFilter);
    api.get('/admin/gigs', { params })
      .then((r) => setGigs(r.data.data || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    api.get('/categories').then((r) => setCategories(r.data.data || [])).catch(() => {});
    fetchGigs();
  }, [catFilter]);

  const handleDelete = async (id) => {
    if (!confirm('ต้องการลบงานนี้ใช่ไหม?')) return;
    try { await api.delete(`/admin/gigs/${id}`); toast.success('ลบงานสำเร็จ'); fetchGigs(); }
    catch { toast.error('ลบไม่สำเร็จ'); }
  };

  return (
    <div>
      <h1 className="text-3xl font-bold text-surface-100 mb-6">จัดการงาน (Gigs)</h1>

      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <form onSubmit={(e) => { e.preventDefault(); fetchGigs(); }} className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-500" />
          <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ค้นหาชื่องาน..."
            className="w-full rounded-xl border border-surface-600 bg-surface-800/60 pl-10 pr-4 py-2.5 text-sm text-surface-100 placeholder:text-surface-500 focus:outline-none focus:ring-2 focus:ring-primary-500/50 transition-all" />
        </form>
        <Select value={catFilter} onChange={(e) => setCatFilter(e.target.value)} className="sm:w-48">
          <option value="">ทุกหมวดหมู่</option>
          {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </Select>
      </div>

      {loading ? <PageSpinner /> : (
        <div className="glass rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-surface-700/50">
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">ID</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">ชื่องาน</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">ผู้สร้าง</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">ราคา</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">สถานะ</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">วันที่สร้าง</th>
                  <th className="px-5 py-3.5 text-right text-xs font-semibold text-surface-400 uppercase">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {gigs.map((g) => (
                  <tr key={g.id} className="border-b border-surface-700/30 hover:bg-surface-800/40 transition-colors">
                    <td className="px-5 py-3.5 text-surface-400">{g.id}</td>
                    <td className="px-5 py-3.5 font-medium text-surface-200 max-w-[200px] truncate">{g.title}</td>
                    <td className="px-5 py-3.5 text-surface-400">{g.owner?.displayName || g.owner?.email || g.ownerId}</td>
                    <td className="px-5 py-3.5 text-surface-300">{formatPrice(g.price)}</td>
                    <td className="px-5 py-3.5"><Badge color={g.isActive ? 'green' : 'gray'}>{g.isActive ? 'เปิด' : 'ปิด'}</Badge></td>
                    <td className="px-5 py-3.5 text-surface-400">{formatDate(g.createdAt)}</td>
                    <td className="px-5 py-3.5 text-right">
                      <Button variant="ghost" size="sm" onClick={() => handleDelete(g.id)}>
                        <Trash2 className="w-4 h-4 text-red-400" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
