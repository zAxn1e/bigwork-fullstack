import { useState, useEffect } from 'react';
import api from '../../api/client';
import { useToast } from '../../contexts/ToastContext';
import { formatDate } from '../../utils/formatDate';
import Badge from '../../components/ui/Badge';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';
import Modal from '../../components/ui/Modal';
import { PageSpinner } from '../../components/ui/Spinner';
import { Search, Edit, Trash2, Save } from 'lucide-react';

export default function AdminUsers() {
  const toast = useToast();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('');
  const [editUser, setEditUser] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [saving, setSaving] = useState(false);

  const fetchUsers = () => {
    setLoading(true);
    const params = {};
    if (search.trim()) params.q = search.trim();
    if (roleFilter) params.role = roleFilter;
    api.get('/admin/users', { params })
      .then((r) => setUsers(r.data.data || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchUsers(); }, [roleFilter]);

  const handleSearch = (e) => { e.preventDefault(); fetchUsers(); };

  const openEdit = (u) => {
    setEditUser(u);
    setEditForm({ firstname: u.firstname, lastname: u.lastname, telephoneNumber: u.telephoneNumber, role: u.role, bio: u.bio || '' });
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.patch(`/admin/users/${editUser.id}`, editForm);
      toast.success('อัปเดตผู้ใช้สำเร็จ');
      setEditUser(null);
      fetchUsers();
    } catch (err) { toast.error(err.response?.data?.message || 'อัปเดตไม่สำเร็จ'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!confirm('ต้องการลบผู้ใช้นี้ใช่ไหม?')) return;
    try {
      await api.delete(`/admin/users/${id}`);
      toast.success('ลบผู้ใช้สำเร็จ');
      fetchUsers();
    } catch (err) { toast.error(err.response?.data?.message || 'ลบไม่สำเร็จ'); }
  };

  const roleColors = { CLIENT: 'purple', FREELANCER: 'cyan', ADMIN: 'yellow' };
  const roleLabels = { CLIENT: 'ผู้ว่าจ้าง', FREELANCER: 'ฟรีแลนซ์', ADMIN: 'แอดมิน' };

  return (
    <div>
      <h1 className="text-3xl font-bold text-surface-100 mb-6">จัดการผู้ใช้งาน</h1>

      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <form onSubmit={handleSearch} className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-500" />
          <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ค้นหาด้วยอีเมลหรือชื่อ..."
            className="w-full rounded-xl border border-surface-600 bg-surface-800/60 pl-10 pr-4 py-2.5 text-sm text-surface-100 placeholder:text-surface-500 focus:outline-none focus:ring-2 focus:ring-primary-500/50 transition-all" />
        </form>
        <Select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)} className="sm:w-40">
          <option value="">ทุกบทบาท</option>
          <option value="CLIENT">ผู้ว่าจ้าง</option>
          <option value="FREELANCER">ฟรีแลนซ์</option>
          <option value="ADMIN">แอดมิน</option>
        </Select>
      </div>

      {loading ? <PageSpinner /> : (
        <div className="glass rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-surface-700/50">
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">ID</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">ชื่อ</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">อีเมล</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">บทบาท</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">วันที่สมัคร</th>
                  <th className="px-5 py-3.5 text-right text-xs font-semibold text-surface-400 uppercase">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className="border-b border-surface-700/30 hover:bg-surface-800/40 transition-colors">
                    <td className="px-5 py-3.5 text-surface-400">{u.id}</td>
                    <td className="px-5 py-3.5 font-medium text-surface-200">{u.displayName || `${u.firstname} ${u.lastname}`}</td>
                    <td className="px-5 py-3.5 text-surface-400">{u.email}</td>
                    <td className="px-5 py-3.5"><Badge color={roleColors[u.role]}>{roleLabels[u.role]}</Badge></td>
                    <td className="px-5 py-3.5 text-surface-400">{formatDate(u.createdAt)}</td>
                    <td className="px-5 py-3.5 text-right">
                      <div className="flex items-center gap-1 justify-end">
                        <Button variant="ghost" size="sm" onClick={() => openEdit(u)}><Edit className="w-4 h-4" /></Button>
                        <Button variant="ghost" size="sm" onClick={() => handleDelete(u.id)}><Trash2 className="w-4 h-4 text-red-400" /></Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <Modal isOpen={!!editUser} onClose={() => setEditUser(null)} title="แก้ไขผู้ใช้">
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input label="ชื่อ" value={editForm.firstname || ''} onChange={(e) => setEditForm({ ...editForm, firstname: e.target.value })} />
            <Input label="นามสกุล" value={editForm.lastname || ''} onChange={(e) => setEditForm({ ...editForm, lastname: e.target.value })} />
          </div>
          <Input label="เบอร์โทร" value={editForm.telephoneNumber || ''} onChange={(e) => setEditForm({ ...editForm, telephoneNumber: e.target.value })} />
          <Select label="บทบาท" value={editForm.role} onChange={(e) => setEditForm({ ...editForm, role: e.target.value })}>
            <option value="CLIENT">ผู้ว่าจ้าง</option>
            <option value="FREELANCER">ฟรีแลนซ์</option>
            <option value="ADMIN">แอดมิน</option>
          </Select>
          <Button type="submit" loading={saving} className="w-full"><Save className="w-4 h-4" /> บันทึก</Button>
        </form>
      </Modal>
    </div>
  );
}
