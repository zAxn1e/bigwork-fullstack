import { useState, useEffect } from 'react';
import api from '../../api/client';
import { PageSpinner } from '../../components/ui/Spinner';
import { Users, Briefcase, ShoppingCart, MessageSquare, FolderKanban } from 'lucide-react';

export default function AdminDashboard() {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/admin/summary')
      .then((r) => setSummary(r.data.data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <PageSpinner />;

  const cards = [
    { label: 'ผู้ใช้งาน', value: summary?.users ?? 0, icon: Users, color: 'from-violet-500 to-purple-600' },
    { label: 'งาน (Gigs)', value: summary?.gigs ?? 0, icon: Briefcase, color: 'from-cyan-500 to-blue-600' },
    { label: 'คำสั่งซื้อ', value: summary?.orders ?? 0, icon: ShoppingCart, color: 'from-emerald-500 to-green-600' },
    { label: 'รีวิว', value: summary?.reviews ?? 0, icon: MessageSquare, color: 'from-amber-500 to-orange-600' },
    { label: 'หมวดหมู่', value: summary?.categories ?? 0, icon: FolderKanban, color: 'from-pink-500 to-rose-600' },
  ];

  return (
    <div>
      <h1 className="text-3xl font-bold text-surface-100 mb-2">แดชบอร์ดแอดมิน</h1>
      <p className="text-surface-400 mb-8">ภาพรวมระบบ BigWork</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-5">
        {cards.map((c) => (
          <div key={c.label} className="glass rounded-2xl p-6 hover:-translate-y-1 transition-all duration-300">
            <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${c.color} flex items-center justify-center mb-4 shadow-lg`}>
              <c.icon className="w-6 h-6 text-white" />
            </div>
            <p className="text-3xl font-bold text-surface-100">{c.value.toLocaleString()}</p>
            <p className="text-sm text-surface-400 mt-1">{c.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
