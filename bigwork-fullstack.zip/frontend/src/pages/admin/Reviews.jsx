import { useState, useEffect } from 'react';
import api from '../../api/client';
import { useToast } from '../../contexts/ToastContext';
import { formatDate } from '../../utils/formatDate';
import StarRating from '../../components/ui/StarRating';
import Button from '../../components/ui/Button';
import { PageSpinner } from '../../components/ui/Spinner';
import { Trash2 } from 'lucide-react';

export default function AdminReviews() {
  const toast = useToast();
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchReviews = () => {
    setLoading(true);
    api.get('/admin/reviews')
      .then((r) => setReviews(r.data.data || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchReviews(); }, []);

  const handleDelete = async (id) => {
    if (!confirm('ต้องการลบรีวิวนี้ใช่ไหม?')) return;
    try { await api.delete(`/admin/reviews/${id}`); toast.success('ลบรีวิวสำเร็จ'); fetchReviews(); }
    catch { toast.error('ลบไม่สำเร็จ'); }
  };

  return (
    <div>
      <h1 className="text-3xl font-bold text-surface-100 mb-6">จัดการรีวิว</h1>

      {loading ? <PageSpinner /> : (
        <div className="glass rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-surface-700/50">
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">ID</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">ผู้เขียน</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">ถึง</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">คะแนน</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">ความคิดเห็น</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">วันที่</th>
                  <th className="px-5 py-3.5 text-right text-xs font-semibold text-surface-400 uppercase">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {reviews.map((r) => (
                  <tr key={r.id} className="border-b border-surface-700/30 hover:bg-surface-800/40 transition-colors">
                    <td className="px-5 py-3.5 text-surface-400">{r.id}</td>
                    <td className="px-5 py-3.5 text-surface-200">{r.author?.displayName || r.authorId}</td>
                    <td className="px-5 py-3.5 text-surface-400">{r.targetUser?.displayName || r.targetUserId}</td>
                    <td className="px-5 py-3.5"><StarRating rating={r.rating} size={14} /></td>
                    <td className="px-5 py-3.5 text-surface-300 max-w-[250px] truncate">{r.comment || '-'}</td>
                    <td className="px-5 py-3.5 text-surface-400">{formatDate(r.createdAt)}</td>
                    <td className="px-5 py-3.5 text-right">
                      <Button variant="ghost" size="sm" onClick={() => handleDelete(r.id)}>
                        <Trash2 className="w-4 h-4 text-red-400" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
