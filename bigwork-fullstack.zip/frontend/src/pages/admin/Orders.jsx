import { useState, useEffect } from 'react';
import api from '../../api/client';
import { useToast } from '../../contexts/ToastContext';
import { formatPrice } from '../../utils/formatPrice';
import { formatDateTime } from '../../utils/formatDate';
import OrderStatusBadge from '../../components/order/OrderStatusBadge';
import Button from '../../components/ui/Button';
import Select from '../../components/ui/Select';
import { PageSpinner } from '../../components/ui/Spinner';

export default function AdminOrders() {
  const toast = useToast();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');

  const fetchOrders = () => {
    setLoading(true);
    const params = {};
    if (filter) params.status = filter;
    api.get('/admin/orders', { params })
      .then((r) => setOrders(r.data.data || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchOrders(); }, [filter]);

  const updateStatus = async (id, status) => {
    try {
      await api.patch(`/admin/orders/${id}/status`, { status });
      toast.success('อัปเดตสถานะสำเร็จ');
      fetchOrders();
    } catch (err) { toast.error(err.response?.data?.message || 'อัปเดตไม่สำเร็จ'); }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
        <h1 className="text-3xl font-bold text-surface-100">จัดการคำสั่งซื้อ</h1>
        <Select value={filter} onChange={(e) => setFilter(e.target.value)} className="w-48">
          <option value="">ทุกสถานะ</option>
          <option value="PENDING">รอดำเนินการ</option>
          <option value="IN_PROGRESS">กำลังดำเนินการ</option>
          <option value="COMPLETED">เสร็จสิ้น</option>
          <option value="CANCELLED">ยกเลิก</option>
        </Select>
      </div>

      {loading ? <PageSpinner /> : (
        <div className="glass rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-surface-700/50">
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">ID</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">งาน</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">ลูกค้า</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">ผู้ขาย</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">ราคา</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">สถานะ</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">วันที่</th>
                  <th className="px-5 py-3.5 text-right text-xs font-semibold text-surface-400 uppercase">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((o) => (
                  <tr key={o.id} className="border-b border-surface-700/30 hover:bg-surface-800/40 transition-colors">
                    <td className="px-5 py-3.5 text-surface-400">{o.id}</td>
                    <td className="px-5 py-3.5 font-medium text-surface-200 max-w-[160px] truncate">{o.gig?.title || o.gigId}</td>
                    <td className="px-5 py-3.5 text-surface-400">{o.client?.displayName || o.clientId}</td>
                    <td className="px-5 py-3.5 text-surface-400">{o.seller?.displayName || o.sellerId}</td>
                    <td className="px-5 py-3.5 text-surface-300">{formatPrice(o.agreedPrice)}</td>
                    <td className="px-5 py-3.5"><OrderStatusBadge status={o.status} /></td>
                    <td className="px-5 py-3.5 text-surface-400 whitespace-nowrap">{formatDateTime(o.createdAt)}</td>
                    <td className="px-5 py-3.5 text-right">
                      <Select value={o.status} onChange={(e) => updateStatus(o.id, e.target.value)} className="w-36 text-xs">
                        <option value="PENDING">รอดำเนินการ</option>
                        <option value="IN_PROGRESS">กำลังดำเนินการ</option>
                        <option value="COMPLETED">เสร็จสิ้น</option>
                        <option value="CANCELLED">ยกเลิก</option>
                      </Select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
