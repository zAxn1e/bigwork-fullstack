import { useState, useEffect } from 'react';
import api from '../../api/client';
import { useToast } from '../../contexts/ToastContext';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Modal from '../../components/ui/Modal';
import { PageSpinner } from '../../components/ui/Spinner';
import { Plus, Edit, Trash2, Save } from 'lucide-react';

export default function AdminCategories() {
  const toast = useToast();
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(null); // null | { mode: 'create' } | { mode: 'edit', cat }
  const [name, setName] = useState('');
  const [saving, setSaving] = useState(false);

  const fetch = () => {
    setLoading(true);
    api.get('/admin/categories')
      .then((r) => setCategories(r.data.data || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetch(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (modal.mode === 'create') {
        await api.post('/admin/categories', { name });
        toast.success('สร้างหมวดหมู่สำเร็จ');
      } else {
        await api.patch(`/admin/categories/${modal.cat.id}`, { name });
        toast.success('อัปเดตหมวดหมู่สำเร็จ');
      }
      setModal(null); setName(''); fetch();
    } catch (err) { toast.error(err.response?.data?.message || 'ไม่สำเร็จ'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!confirm('ต้องการลบหมวดหมู่นี้ใช่ไหม?')) return;
    try { await api.delete(`/admin/categories/${id}`); toast.success('ลบสำเร็จ'); fetch(); }
    catch (err) { toast.error(err.response?.data?.message || 'ลบไม่สำเร็จ'); }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-surface-100">จัดการหมวดหมู่</h1>
        <Button onClick={() => { setModal({ mode: 'create' }); setName(''); }}>
          <Plus className="w-4 h-4" /> เพิ่มหมวดหมู่
        </Button>
      </div>

      {loading ? <PageSpinner /> : (
        <div className="glass rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-surface-700/50">
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">ID</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">ชื่อหมวดหมู่</th>
                  <th className="px-5 py-3.5 text-left text-xs font-semibold text-surface-400 uppercase">จำนวนงาน</th>
                  <th className="px-5 py-3.5 text-right text-xs font-semibold text-surface-400 uppercase">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {categories.map((c) => (
                  <tr key={c.id} className="border-b border-surface-700/30 hover:bg-surface-800/40 transition-colors">
                    <td className="px-5 py-3.5 text-surface-400">{c.id}</td>
                    <td className="px-5 py-3.5 font-medium text-surface-200">{c.name}</td>
                    <td className="px-5 py-3.5 text-surface-400">{c._count?.gigs ?? '-'}</td>
                    <td className="px-5 py-3.5 text-right">
                      <div className="flex items-center gap-1 justify-end">
                        <Button variant="ghost" size="sm" onClick={() => { setModal({ mode: 'edit', cat: c }); setName(c.name); }}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleDelete(c.id)}>
                          <Trash2 className="w-4 h-4 text-red-400" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <Modal isOpen={!!modal} onClose={() => setModal(null)} title={modal?.mode === 'create' ? 'เพิ่มหมวดหมู่' : 'แก้ไขหมวดหมู่'}>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input label="ชื่อหมวดหมู่" value={name} onChange={(e) => setName(e.target.value)} required placeholder="เช่น Web Development" />
          <Button type="submit" loading={saving} className="w-full"><Save className="w-4 h-4" /> บันทึก</Button>
        </form>
      </Modal>
    </div>
  );
}
