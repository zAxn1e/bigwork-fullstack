import StarRating from '../ui/StarRating';
import { formatDate } from '../../utils/formatDate';
import { mediaUrl } from '../../utils/media';
import { getUserProfileImage } from '../../utils/userProfileImage';
import { User } from 'lucide-react';

export default function ReviewCard({ review }) {
  const author = review.author;
  const authorProfileImage = getUserProfileImage(author);

  return (
    <div className="glass rounded-xl p-5">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-full overflow-hidden bg-gradient-to-br from-primary-500 to-accent-500 flex items-center justify-center text-sm font-bold text-white shrink-0">
          {authorProfileImage ? (
            <img src={mediaUrl(authorProfileImage)} alt="" className="w-full h-full object-cover" />
          ) : (
            author?.firstname?.[0] || <User className="w-4 h-4" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <p className="text-sm font-semibold text-surface-200">
              {author?.displayName || `${author?.firstname || ''} ${author?.lastname || ''}`}
            </p>
            <span className="text-xs text-surface-500">{formatDate(review.createdAt)}</span>
          </div>
          <StarRating rating={review.rating} size={14} />
          {review.comment && (
            <p className="mt-2 text-sm text-surface-300 leading-relaxed">{review.comment}</p>
          )}
        </div>
      </div>
    </div>
  );
}
