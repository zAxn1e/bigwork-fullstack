import { Link } from 'react-router-dom';
import { formatPrice } from '../../utils/formatPrice';
import { mediaUrl } from '../../utils/media';
import { getUserProfileImage } from '../../utils/userProfileImage';
import StarRating from '../ui/StarRating';
import Badge from '../ui/Badge';
import { User, ImageOff } from 'lucide-react';

export default function GigCard({ gig }) {
  const thumb =
    gig.mediaLinks?.[0]?.mediaAsset?.thumbnailUrl ||
    gig.mediaLinks?.[0]?.mediaAsset?.webpUrl;
  const ownerProfileImage = getUserProfileImage(gig.owner);

  return (
    <Link
      to={`/gigs/${gig.id}`}
      className="group glass rounded-2xl overflow-hidden flex flex-col transition-all duration-300 hover:shadow-xl hover:shadow-primary-500/10 hover:-translate-y-1"
    >
      {/* Image */}
      <div className="relative aspect-[16/10] bg-surface-800 overflow-hidden">
        {thumb ? (
          <img
            src={mediaUrl(thumb)}
            alt={gig.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <ImageOff className="w-10 h-10 text-surface-700" />
          </div>
        )}
        {gig.category && (
          <div className="absolute top-3 left-3">
            <Badge color="purple">{gig.category.name}</Badge>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex flex-col flex-1 p-4 gap-2.5">
        {/* Owner */}
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full overflow-hidden bg-gradient-to-br from-primary-500 to-accent-500 flex items-center justify-center text-[11px] font-bold text-white shrink-0">
            {ownerProfileImage ? (
              <img src={mediaUrl(ownerProfileImage)} alt="" className="w-full h-full object-cover" />
            ) : (
              gig.owner?.firstname?.[0] || <User className="w-3.5 h-3.5" />
            )}
          </div>
          <span className="text-xs text-surface-400 truncate">
            {gig.owner?.displayName || `${gig.owner?.firstname || ''} ${gig.owner?.lastname || ''}`}
          </span>
        </div>

        {/* Title */}
        <h3 className="text-sm font-semibold text-surface-100 leading-snug line-clamp-2 group-hover:text-primary-300 transition-colors">
          {gig.title}
        </h3>

        {/* Price */}
        <div className="mt-auto pt-2 border-t border-surface-700/50 flex items-center justify-between">
          <span className="text-xs text-surface-500">เริ่มต้นที่</span>
          <span className="text-base font-bold gradient-text">{formatPrice(gig.price)}</span>
        </div>
      </div>
    </Link>
  );
}
