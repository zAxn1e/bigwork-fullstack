import Badge from '../ui/Badge';

const statusMap = {
  PENDING:     { label: 'รอดำเนินการ',  color: 'yellow' },
  IN_PROGRESS: { label: 'กำลังดำเนินการ', color: 'blue'   },
  COMPLETED:   { label: 'เสร็จสิ้น',    color: 'green'  },
  CANCELLED:   { label: 'ยกเลิก',      color: 'red'    },
};

export default function OrderStatusBadge({ status }) {
  const s = statusMap[status] || { label: status, color: 'gray' };
  return <Badge color={s.color}>{s.label}</Badge>;
}
