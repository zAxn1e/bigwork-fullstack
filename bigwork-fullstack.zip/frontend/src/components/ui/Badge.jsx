const colors = {
  green:  'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
  blue:   'bg-blue-500/15 text-blue-400 border-blue-500/30',
  yellow: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
  red:    'bg-red-500/15 text-red-400 border-red-500/30',
  purple: 'bg-primary-500/15 text-primary-400 border-primary-500/30',
  cyan:   'bg-cyan-500/15 text-cyan-400 border-cyan-500/30',
  gray:   'bg-surface-600/30 text-surface-300 border-surface-500/30',
};

export default function Badge({ children, color = 'purple', className = '' }) {
  return (
    <span className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-semibold ${colors[color]} ${className}`}>
      {children}
    </span>
  );
}
