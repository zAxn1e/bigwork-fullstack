import { useEffect } from 'react';
import { X } from 'lucide-react';

export default function Modal({ isOpen, onClose, title, children, size = 'md' }) {
  useEffect(() => {
    if (isOpen) document.body.style.overflow = 'hidden';
    else document.body.style.overflow = '';
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  if (!isOpen) return null;

  const widths = {
    sm: 'max-w-md',
    md: 'max-w-lg',
    lg: 'max-w-2xl',
    xl: 'max-w-4xl',
  };

  return (
    <div className="fixed inset-0 z-[999] flex items-center justify-center p-4">
      {/* backdrop */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      {/* content */}
      <div className={`relative w-full ${widths[size]} glass rounded-2xl animate-slide-up max-h-[85vh] flex flex-col`}>
        {/* header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-surface-700/50">
          <h3 className="text-lg font-bold text-surface-100">{title}</h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-surface-700/60 transition-colors cursor-pointer">
            <X className="w-5 h-5 text-surface-400" />
          </button>
        </div>
        {/* body */}
        <div className="px-6 py-5 overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}
