import { forwardRef } from 'react';

const Input = forwardRef(({ label, error, className = '', ...props }, ref) => (
  <div className="flex flex-col gap-1.5">
    {label && (
      <label className="text-sm font-medium text-surface-300">{label}</label>
    )}
    <input
      ref={ref}
      className={`w-full rounded-xl border border-surface-600 bg-surface-800/60 px-4 py-2.5 text-sm text-surface-100
        placeholder:text-surface-500 transition-all duration-200
        focus:outline-none focus:ring-2 focus:ring-primary-500/50 focus:border-primary-500
        disabled:opacity-50 disabled:cursor-not-allowed
        ${error ? 'border-red-500 focus:ring-red-500/50' : ''} ${className}`}
      {...props}
    />
    {error && <p className="text-xs text-red-400">{error}</p>}
  </div>
));

Input.displayName = 'Input';
export default Input;
