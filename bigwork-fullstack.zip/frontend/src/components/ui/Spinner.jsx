import { Loader2 } from 'lucide-react';

export default function Spinner({ size = 'md', className = '' }) {
  const s = size === 'sm' ? 'w-5 h-5' : size === 'lg' ? 'w-10 h-10' : 'w-7 h-7';
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <Loader2 className={`${s} animate-spin text-primary-400`} />
    </div>
  );
}

export function PageSpinner() {
  return (
    <div className="flex items-center justify-center min-h-[50vh]">
      <div className="flex flex-col items-center gap-4">
        <Loader2 className="w-10 h-10 animate-spin text-primary-400" />
        <p className="text-sm text-surface-400">กำลังโหลด...</p>
      </div>
    </div>
  );
}
