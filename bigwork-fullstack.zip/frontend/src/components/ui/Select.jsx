import { forwardRef } from 'react';
import { ChevronDown } from 'lucide-react';

const Select = forwardRef(({ label, error, children, className = '', ...props }, ref) => (
  <div className="flex flex-col gap-1.5">
    {label && (
      <label className="text-sm font-medium text-surface-300">{label}</label>
    )}
    <div className="relative">
      <select
        ref={ref}
        className={`w-full appearance-none rounded-xl border border-surface-600 bg-surface-800/60 px-4 py-2.5 pr-10 text-sm text-surface-100
          transition-all duration-200
          focus:outline-none focus:ring-2 focus:ring-primary-500/50 focus:border-primary-500
          disabled:opacity-50 disabled:cursor-not-allowed
          ${error ? 'border-red-500' : ''} ${className}`}
        {...props}
      >
        {children}
      </select>
      <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
    </div>
    {error && <p className="text-xs text-red-400">{error}</p>}
  </div>
));

Select.displayName = 'Select';
export default Select;
