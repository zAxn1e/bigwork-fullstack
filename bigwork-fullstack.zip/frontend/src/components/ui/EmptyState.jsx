export default function EmptyState({ icon: Icon, title, description, children }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      {Icon && (
        <div className="mb-4 rounded-2xl bg-surface-800 p-4">
          <Icon className="w-10 h-10 text-surface-500" />
        </div>
      )}
      <h3 className="text-lg font-semibold text-surface-300">{title}</h3>
      {description && <p className="mt-1 text-sm text-surface-500 max-w-md">{description}</p>}
      {children && <div className="mt-5">{children}</div>}
    </div>
  );
}
