import { Star } from 'lucide-react';

export default function StarRating({ rating = 0, size = 16, interactive = false, onChange }) {
  return (
    <div className="inline-flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <button
          key={i}
          type="button"
          disabled={!interactive}
          onClick={() => interactive && onChange?.(i)}
          className={`transition-transform duration-150 ${interactive ? 'cursor-pointer hover:scale-125' : 'cursor-default'}`}
        >
          <Star
            size={size}
            className={i <= rating ? 'fill-amber-400 text-amber-400' : 'fill-none text-surface-600'}
          />
        </button>
      ))}
    </div>
  );
}
