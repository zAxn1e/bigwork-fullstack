import { Link } from 'react-router-dom';
import { Briefcase, Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-surface-700/30 bg-surface-950/80 mt-auto">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 sm:col-span-2 lg:col-span-1">
            <Link to="/" className="flex items-center gap-2.5 mb-4 group">
              <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-br from-primary-500 to-accent-500 shadow-lg shadow-primary-500/25">
                <Briefcase className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold gradient-text">BigWork</span>
            </Link>
            <p className="text-sm text-surface-400 leading-relaxed">
              แพลตฟอร์มฟรีแลนซ์ที่เชื่อมต่อผู้ว่าจ้างกับฟรีแลนซ์คุณภาพ
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-sm font-semibold text-surface-200 mb-3">เมนูหลัก</h4>
            <ul className="space-y-2">
              <li><Link to="/gigs" className="text-sm text-surface-400 hover:text-primary-400 transition-colors">ค้นหางาน</Link></li>
              <li><Link to="/register" className="text-sm text-surface-400 hover:text-primary-400 transition-colors">สมัครสมาชิก</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-surface-200 mb-3">สำหรับฟรีแลนซ์</h4>
            <ul className="space-y-2">
              <li><Link to="/profile/gigs" className="text-sm text-surface-400 hover:text-primary-400 transition-colors">จัดการงาน</Link></li>
              <li><Link to="/profile/orders" className="text-sm text-surface-400 hover:text-primary-400 transition-colors">คำสั่งซื้อ</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-surface-200 mb-3">เกี่ยวกับ</h4>
            <ul className="space-y-2">
              <li><span className="text-sm text-surface-400">BigWork Internal API</span></li>
              <li><span className="text-sm text-surface-400">เวอร์ชัน 1.0.0</span></li>
            </ul>
          </div>
        </div>

        <hr className="my-8 border-surface-800" />

        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-surface-500">
            © {new Date().getFullYear()} BigWork. สงวนลิขสิทธิ์
          </p>
          <p className="flex items-center gap-1 text-xs text-surface-500">
            สร้างด้วย <Heart className="w-3 h-3 text-red-500 fill-red-500" /> โดย LnwZa Team
          </p>
        </div>
      </div>
    </footer>
  );
}
