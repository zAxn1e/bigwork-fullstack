import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useState } from 'react';
import { mediaUrl } from '../../utils/media';
import { getUserProfileImage } from '../../utils/userProfileImage';
import {
  Briefcase, LogIn, LogOut, User, Menu, X, ChevronDown,
  LayoutDashboard, ShieldCheck, Search
} from 'lucide-react';
import Button from '../ui/Button';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const userProfileImage = getUserProfileImage(user);

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-50 glass border-b border-surface-700/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-br from-primary-500 to-accent-500 shadow-lg shadow-primary-500/25 transition-transform group-hover:scale-105">
              <Briefcase className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold gradient-text hidden sm:block">BigWork</span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-1">
            <Link to="/gigs" className="px-4 py-2 rounded-lg text-sm font-medium text-surface-300 hover:text-white hover:bg-surface-700/50 transition-all flex items-center gap-1.5">
              <Search className="w-4 h-4" />
              ค้นหางาน
            </Link>
            {user && (
              <>
                <Link to="/profile/orders" className="px-4 py-2 rounded-lg text-sm font-medium text-surface-300 hover:text-white hover:bg-surface-700/50 transition-all">
                  คำสั่งซื้อ
                </Link>
                {user.role === 'FREELANCER' && (
                  <Link to="/profile/gigs" className="px-4 py-2 rounded-lg text-sm font-medium text-surface-300 hover:text-white hover:bg-surface-700/50 transition-all">
                    งานของฉัน
                  </Link>
                )}
                {user.role === 'ADMIN' && (
                  <Link to="/admin" className="px-4 py-2 rounded-lg text-sm font-medium text-amber-400 hover:text-amber-300 hover:bg-amber-500/10 transition-all flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4" />
                    แอดมิน
                  </Link>
                )}
              </>
            )}
          </nav>

          {/* Desktop right */}
          <div className="hidden md:flex items-center gap-3">
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setDropdownOpen(!dropdownOpen)}
                  className="flex items-center gap-2.5 rounded-xl px-3 py-2 hover:bg-surface-700/50 transition-all cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-full overflow-hidden bg-gradient-to-br from-primary-500 to-accent-500 flex items-center justify-center text-white text-sm font-bold">
                    {userProfileImage ? (
                      <img src={mediaUrl(userProfileImage)} alt="" className="w-full h-full object-cover" />
                    ) : (
                      user.firstname?.[0] || 'U'
                    )}
                  </div>
                  <span className="text-sm font-medium text-surface-200 max-w-[120px] truncate">
                    {user.displayName || `${user.firstname} ${user.lastname}`}
                  </span>
                  <ChevronDown className={`w-4 h-4 text-surface-400 transition-transform ${dropdownOpen ? 'rotate-180' : ''}`} />
                </button>

                {dropdownOpen && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setDropdownOpen(false)} />
                    <div className="absolute right-0 mt-2 w-56 glass rounded-xl py-2 z-50 animate-fade-in shadow-2xl">
                      <div className="px-4 py-2 border-b border-surface-700/50">
                        <p className="text-sm font-semibold text-surface-200">{user.displayName || `${user.firstname} ${user.lastname}`}</p>
                        <p className="text-xs text-surface-500">{user.email}</p>
                      </div>
                      <Link to="/profile" onClick={() => setDropdownOpen(false)}
                        className="flex items-center gap-2.5 px-4 py-2.5 text-sm text-surface-300 hover:bg-surface-700/50 hover:text-white transition-all">
                        <User className="w-4 h-4" /> โปรไฟล์
                      </Link>
                      {user.role === 'ADMIN' && (
                        <Link to="/admin" onClick={() => setDropdownOpen(false)}
                          className="flex items-center gap-2.5 px-4 py-2.5 text-sm text-amber-400 hover:bg-amber-500/10 transition-all">
                          <LayoutDashboard className="w-4 h-4" /> แดชบอร์ดแอดมิน
                        </Link>
                      )}
                      <hr className="my-1 border-surface-700/50" />
                      <button onClick={() => { setDropdownOpen(false); handleLogout(); }}
                        className="flex items-center gap-2.5 px-4 py-2.5 text-sm text-red-400 hover:bg-red-500/10 w-full transition-all cursor-pointer">
                        <LogOut className="w-4 h-4" /> ออกจากระบบ
                      </button>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="sm" onClick={() => navigate('/login')}>
                  <LogIn className="w-4 h-4" /> เข้าสู่ระบบ
                </Button>
                <Button size="sm" onClick={() => navigate('/register')}>
                  สมัครสมาชิก
                </Button>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <button onClick={() => setMobileOpen(!mobileOpen)} className="md:hidden p-2 rounded-lg hover:bg-surface-700/50 transition-colors cursor-pointer">
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden border-t border-surface-700/30 glass animate-fade-in">
          <div className="px-4 py-4 space-y-1">
            <Link to="/gigs" onClick={() => setMobileOpen(false)}
              className="flex items-center gap-2.5 px-4 py-3 rounded-xl text-sm font-medium text-surface-300 hover:bg-surface-700/50 hover:text-white transition-all">
              <Search className="w-4 h-4" /> ค้นหางาน
            </Link>
            {user ? (
              <>
                <Link to="/profile" onClick={() => setMobileOpen(false)}
                  className="flex items-center gap-2.5 px-4 py-3 rounded-xl text-sm font-medium text-surface-300 hover:bg-surface-700/50 hover:text-white transition-all">
                  <User className="w-4 h-4" /> โปรไฟล์
                </Link>
                <Link to="/profile/orders" onClick={() => setMobileOpen(false)}
                  className="flex items-center gap-2.5 px-4 py-3 rounded-xl text-sm font-medium text-surface-300 hover:bg-surface-700/50 hover:text-white transition-all">
                  คำสั่งซื้อ
                </Link>
                {user.role === 'FREELANCER' && (
                  <Link to="/profile/gigs" onClick={() => setMobileOpen(false)}
                    className="flex items-center gap-2.5 px-4 py-3 rounded-xl text-sm font-medium text-surface-300 hover:bg-surface-700/50 hover:text-white transition-all">
                    งานของฉัน
                  </Link>
                )}
                {user.role === 'ADMIN' && (
                  <Link to="/admin" onClick={() => setMobileOpen(false)}
                    className="flex items-center gap-2.5 px-4 py-3 rounded-xl text-sm font-medium text-amber-400 hover:bg-amber-500/10 transition-all">
                    <ShieldCheck className="w-4 h-4" /> แอดมิน
                  </Link>
                )}
                <hr className="border-surface-700/50" />
                <button onClick={() => { setMobileOpen(false); handleLogout(); }}
                  className="flex items-center gap-2.5 px-4 py-3 rounded-xl text-sm font-medium text-red-400 hover:bg-red-500/10 w-full transition-all cursor-pointer">
                  <LogOut className="w-4 h-4" /> ออกจากระบบ
                </button>
              </>
            ) : (
              <div className="flex flex-col gap-2 pt-2">
                <Button variant="ghost" onClick={() => { setMobileOpen(false); navigate('/login'); }}>เข้าสู่ระบบ</Button>
                <Button onClick={() => { setMobileOpen(false); navigate('/register'); }}>สมัครสมาชิก</Button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
