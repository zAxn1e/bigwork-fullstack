import { NavLink, Outlet } from 'react-router-dom';
import {
  LayoutDashboard, Users, FolderKanban, Briefcase,
  ShoppingCart, MessageSquare, ArrowLeft
} from 'lucide-react';
import { Link } from 'react-router-dom';

const links = [
  { to: '/admin',            icon: LayoutDashboard, label: 'แดชบอร์ด',   end: true },
  { to: '/admin/users',      icon: Users,           label: 'ผู้ใช้งาน'         },
  { to: '/admin/categories', icon: FolderKanban,    label: 'หมวดหมู่'          },
  { to: '/admin/gigs',       icon: Briefcase,       label: 'งาน (Gigs)'        },
  { to: '/admin/orders',     icon: ShoppingCart,     label: 'คำสั่งซื้อ'       },
  { to: '/admin/reviews',    icon: MessageSquare,    label: 'รีวิว'             },
];

export default function AdminLayout() {
  return (
    <div className="flex min-h-[calc(100dvh-64px)]">
      {/* Sidebar */}
      <aside className="hidden lg:flex w-64 flex-col border-r border-surface-700/30 bg-surface-900/60 p-4">
        <Link to="/" className="flex items-center gap-2 mb-6 text-sm text-surface-400 hover:text-primary-400 transition-colors">
          <ArrowLeft className="w-4 h-4" /> กลับหน้าหลัก
        </Link>
        <h2 className="text-xs font-bold uppercase tracking-wider text-surface-500 mb-4 px-3">แอดมิน</h2>
        <nav className="flex flex-col gap-1">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all
                ${isActive
                  ? 'bg-primary-500/15 text-primary-400 shadow-sm'
                  : 'text-surface-400 hover:text-surface-200 hover:bg-surface-700/40'}`
              }
            >
              <l.icon className="w-4.5 h-4.5" />
              {l.label}
            </NavLink>
          ))}
        </nav>
      </aside>

      {/* Mobile nav */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 glass border-t border-surface-700/30">
        <div className="flex items-center justify-around py-2">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              className={({ isActive }) =>
                `flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-lg text-[10px] font-medium transition-all
                ${isActive ? 'text-primary-400' : 'text-surface-500'}`
              }
            >
              <l.icon className="w-4.5 h-4.5" />
              {l.label}
            </NavLink>
          ))}
        </div>
      </div>

      {/* Content */}
      <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 pb-24 lg:pb-8">
        <Outlet />
      </main>
    </div>
  );
}
