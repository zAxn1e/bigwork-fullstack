const API_BASE = import.meta.env.VITE_API_BASE_URL || 'https://api.noctradev.com';

export function mediaUrl(path) {
  if (!path) return null;
  if (path.startsWith('http')) return path;
  return `${API_BASE}${path}`;
}
