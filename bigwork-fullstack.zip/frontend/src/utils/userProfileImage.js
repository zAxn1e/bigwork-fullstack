export function getUserProfileImage(user) {
  if (!user) return null;
  return (
    user.profileImageUrl ||
    user.profileImage?.url ||
    user.profileImage?.path ||
    user.avatarUrl ||
    user.avatar ||
    user.imageUrl ||
    user.image ||
    null
  );
}
