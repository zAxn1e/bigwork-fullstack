# BigWork Frontend 🚀

ระบบ Frontend สำหรับ **BigWork Freelance Marketplace** แพลตฟอร์มที่เชื่อมต่อระหว่างผู้ว่าจ้าง (Clients) และฟรีแลนซ์ (Freelancers) โดยออกแบบมาให้ใช้งานง่าย รวดเร็ว และมีดีไซน์ที่ทันสมัย (Glassmorphism) 

## 🛠 Tech Stack

- **Framework**: React 19 + Vite 8
- **Routing**: React Router v7
- **Styling**: TailwindCSS v4
- **API Client**: Axios (พร้อม Interceptors จัดการ Token)
- **Icons**: Lucide React

## ✨ Features

- **Authentication**: ระบบ Login/Register แยก Role ระหว่าง Client และ Freelancer
- **Public & Gig Browsing**: ค้นหางาน, กรองตามหมวดหมู่, ดูรายละเอียดงานและรีวิว
- **Profile Management**: จัดการข้อมูลส่วนตัว, ทักษะ (Skills), และอัปโหลดรูปโปรไฟล์
- **Freelancer Dashboard**: สร้าง, แก้ไข, ลบ, และเปิด/ปิดรับงาน (My Gigs) พร้อมอัปโหลดรูปผลงาน
- **Order System**: ระบบสั่งจ้างงาน, อัปเดตสถานะ (รอดำเนินการ, กำลังดำเนินการ, เสร็จสิ้น, ยกเลิก)
- **Review System**: ให้คะแนนและเขียนรีวิวหลังงานเสร็จสิ้น
- **Admin Dashboard**: จัดการผู้ใช้งาน, หมวดหมู่, งาน, คำสั่งซื้อ, และรีวิวทั้งหมดในระบบ

## 🚀 Getting Started (วิธีรันโปรเจค)

### 1. Prerequisites
- Node.js (แนะนำเวอร์ชัน 18 ขึ้นไป)
- npm หรือ yarn

### 2. Installation
โคลนโปรเจคและติดตั้ง dependencies:
```bash
git clone https://github.com/zAxn1e/bigwork-frontend.git
cd bigwork-frontend
npm install
```

### 3. Environment Variables
สร้างไฟล์ `.env` ในโฟลเดอร์ root ของโปรเจค (สามารถคัดลอกรูปแบบจาก `.env.example` ได้):
```bash
cp .env.example .env
```
จากนั้นเปิดไฟล์ `.env` และตั้งค่าดังนี้:
```env
VITE_API_BASE_URL=https://api.noctradev.com
VITE_API_KEY=your_api_key_here
```

### 4. Run Development Server
```bash
npm run dev
```
โปรเจคจะรันที่ `http://localhost:5173/`

### 5. Build for Production
```bash
npm run build
```

## 📂 Folder Structure

```
src/
├── api/            # การตั้งค่า Axios และ Interceptors
├── assets/         # ไฟล์รูปภาพหรือ asset คงที่อื่นๆ
├── components/     # UI components ที่ใช้ซ้ำได้ (UI, Layout, Domain-specific)
├── contexts/       # React Contexts (Auth, Toast)
├── pages/          # หน้าเพจต่างๆ ของระบบ (แบ่งตาม Route)
│   └── admin/      # หน้า Dashboard และการจัดการของ Admin
├── utils/          # ฟังก์ชันช่วยเหลือ (Format price, date, media url)
├── App.jsx         # ตั้งค่า Router และ Layout หลัก
├── index.css       # Design System, Tailwind directives, Animations
└── main.jsx        # Entry point ของ React
```

## 🔒 Security Note
- ห้าม commit ไฟล์ `.env` ขึ้น Git เด็ดขาด
- ระบบใช้การยืนยันตัวตนแบบ 2 ชั้นคือ `x-api-key` (สำหรับทุก request) และ `Bearer Token` (สำหรับ request ที่ต้องการการยืนยันตัวตน)
